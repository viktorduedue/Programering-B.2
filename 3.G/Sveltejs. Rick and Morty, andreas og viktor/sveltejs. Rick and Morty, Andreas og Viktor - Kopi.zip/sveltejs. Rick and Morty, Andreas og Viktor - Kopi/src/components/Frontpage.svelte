<script>
</script>

<main class='page'>
    <div class="text">
        <h2>Welcome to the Rick and Morty zone</h2>
    </div>
    <img src="./assets/Rick and morty, transparent.webp" alt="">
</main>

<style>
	main{
        display:grid;
        grid-template-rows: 2fr 8fr;

    }

</style>